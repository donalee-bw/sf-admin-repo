---
name: sfdc-ric-scoring
description: Scores proposed Salesforce changes on Risk, Impact, and Complexity (1-5 each). The composite score routes changes to admin-autonomous (Green), architect-notified (Yellow), or architect-required (Red). Run after sfdc-impact-analysis, before building the change.
---

# RIC scoring

Score every proposed change on three dimensions. The composite score determines whether the admin proceeds autonomously or routes to the Architect for QA.

## When to use

- After `sfdc-impact-analysis` has produced a dependency table
- When the `sfdc-change-management` rule prescribes step 3 (RIC score)
- Composed by `sfdc-change-reviewer` agent for aggregate change sets

## Inputs

- The dependency table from `sfdc-impact-analysis`
- Domain context from `context/sfdc/` (documented fragile areas, integration points)
- The proposed change description

## Scoring dimensions

### Risk (R) -- What could break?

| Score | Criteria |
|-------|----------|
| 1 | Additive-only, no dependencies. New report, new dashboard, new field with no automation. |
| 2 | Low-dependency modification. Page layout change, help text, field description. |
| 3 | Component with 3-4 dependents. Field used in a few flows or reports. |
| 4 | Automation/flows with cross-object effects. Components read by integrations. |
| 5 | Circular automation (e.g., engagement cycle). Permission model changes. Integration endpoints. |

### Impact (I) -- Who or what is affected?

| Score | Criteria |
|-------|----------|
| 1 | Admin/internal visibility only. Reports, dashboards, list views. |
| 2 | Single team's workflow. One team's page layout or validation rule. |
| 3 | Multiple teams or >50 users affected. |
| 4 | Customer-facing processes or data integrity. Fields feeding external systems, conversion logic. |
| 5 | Revenue pipeline, compliance, or org-wide automation. Opportunity stages, lead routing, cadence logic. |

### Complexity (C) -- How hard to implement and test?

| Score | Criteria |
|-------|----------|
| 1 | Single-component, declarative, no logic. Add a field, modify a layout. |
| 2 | Multi-component, declarative, simple logic. Validation rule with straightforward formula. |
| 3 | Multi-component with conditional logic. Flow with decision elements, cross-object formula fields. |
| 4 | Cross-object automation with timing/order dependencies. Record-triggered flows updating related records. |
| 5 | Multi-system change or Apex required. SF + external API, trigger + flow interaction, batch processing. |

## Routing

| Composite (R+I+C) | Zone | Action |
|--------------------|------|--------|
| 3-6 | **Green** | Admin proceeds autonomously. Document in change log. |
| 7-9 | **Yellow** | Admin proceeds. Architect notified async. Change log must include RIC score card with rationale. |
| 10-15 | **Red** | STOP. Present score card. Architect must review and approve before production deployment. Admin may continue sandbox work while awaiting review. |

## Override rules

- Any single dimension at **5** forces the composite to **Yellow minimum**, regardless of other scores.
- When in doubt, **round UP**. False positives (unnecessary architect review) are cheaper than false negatives (broken production).

## Output format

```
## RIC Score Card

| Dimension | Score | Rationale |
|-----------|-------|-----------|
| Risk | X/5 | [one sentence citing dependency count or pattern] |
| Impact | X/5 | [one sentence citing affected users or processes] |
| Complexity | X/5 | [one sentence citing component count or logic depth] |
| **Total** | **X/15** | **[Green/Yellow/Red]** |

Routing: [Admin proceeds / Architect notification required / Architect review required]
```

If Red, append:

```
### Architect review request

**Change summary**: [one sentence]
**Key risks**: [bulleted list of top concerns]
**Sandbox status**: [tested / not yet tested]
**Blocking question for Architect**: [specific question, not generic "is this ok?"]
```

## Scoring from impact analysis data

Use the `sfdc-impact-analysis` output to drive scores:

- **Dependent count**: 0 = R1, 1-2 = R2, 3-4 = R3, 5+ = R4, circular/integration = R5
- **Would-break count**: 0 = no adjustment, 1+ = raise R by 1 (cap at 5)
- **Data population**: <100 records = no adjustment, 100-10K = raise I by 1, >10K = raise I by 2 (cap at 5)
- **Domain flags**: any flag from `context/sfdc/` raises the relevant dimension by 1

These are starting points. Adjust based on the specific change context.
