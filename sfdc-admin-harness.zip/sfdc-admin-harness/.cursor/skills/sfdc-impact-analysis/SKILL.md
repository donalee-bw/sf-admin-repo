---
name: sfdc-impact-analysis
description: Analyzes dependencies and downstream effects before any Salesforce metadata change. Run before modifying fields, flows, validation rules, or any metadata component. Feeds directly into RIC scoring.
---

# Impact analysis

Identify everything that depends on a Salesforce component before changing it. This skill produces the dependency data that `sfdc-ric-scoring` uses to score the change.

## When to use

- Before modifying or deleting any field, flow, validation rule, Apex class, or permission set
- Before renaming any metadata component
- When the `sfdc-change-management` rule prescribes step 2 (Impact analysis)

## Inputs

The admin provides or you infer:
- **Component type**: field, flow, validation rule, Apex class, trigger, permission set, page layout
- **Component name**: API name (e.g., `Outreach_Stage__c`, `Lead_AfterUpdate_SetOutreachStage`)
- **Change type**: modify, delete, rename, deactivate

## Process

### 1. Retrieve latest metadata

```bash
sf project retrieve start --target-org sandbox --metadata [ComponentType]:[ComponentName]
```

If the component exists only in the local source and hasn't been deployed, skip this step.

### 2. Search for references in the project

Search `force-app/` for all references to the component name:

- **Flows** (`.flow-meta.xml`): field references in conditions, assignments, formulas, record lookups
- **Validation rules** (`.validationRule-meta.xml`): field references in formulas
- **Apex classes** (`.cls`): field and object references in SOQL, DML, property access
- **Apex triggers** (`.trigger`): field and object references
- **Page layouts** (`.layout-meta.xml`): field placement
- **Permission sets** (`.permissionset-meta.xml`): field-level security grants
- **Reports** (if retrieved): field usage in filters, columns, groupings
- **Formula fields**: cross-object references

Use grep/search across the source tree. Count distinct files referencing the component.

### 3. Check data population

For field changes, run a SOQL query to understand data impact:

```bash
sf data query --query "SELECT COUNT(Id) FROM [Object] WHERE [Field] != null" --target-org sandbox
```

For fields with high population (>1000 records with data), flag as higher impact.

### 4. Check domain context

Read `context/sfdc/` for any documented guardrails about this component:
- Is it part of a fragile automation cycle?
- Is it an integration touchpoint?
- Are there documented consolidation constraints?

### 5. Present the dependency table

```
## Impact Analysis: [Component Name]

Change type: [modify/delete/rename/deactivate]

### Dependencies

| Dependent component | Type | Relationship | Risk if changed |
|---------------------|------|-------------|-----------------|
| [name] | Flow | References field in condition | [would break / would need update / informational] |
| [name] | Validation rule | Uses field in formula | [would break / ...] |
| ... | ... | ... | ... |

### Data impact

- Records with data in this field: [count]
- Percentage of total records: [x%]

### Domain flags

- [any flags from context/sfdc/ files]

### Summary

- Total dependents: [count]
- Would-break dependents: [count]
- Recommendation: [proceed with caution / update dependents first / escalate to Architect]
```

## Output

The dependency table feeds directly into `sfdc-ric-scoring`:
- Dependent count drives the **Risk** dimension
- Affected user scope drives the **Impact** dimension
- Number of components to update drives the **Complexity** dimension
