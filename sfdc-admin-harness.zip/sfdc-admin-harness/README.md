# Salesforce Admin AI Harness

AI guardrails, skills, and agents for junior Salesforce admins using Claude Code/Cowork. Two-layer architecture: a generic SF admin foundation plus an org-specific domain overlay.

## How it works

```
Rules (always-on)          Skills (step-by-step)         Agents (autonomous)
─────────────────          ─────────────────────         ───────────────────
sfdc-safety                sfdc-impact-analysis          sfdc-change-reviewer
sfdc-naming                sfdc-ric-scoring               └─ composes impact + RIC
sfdc-change-management     sfdc-deployment               sfdc-deployment-manager
bw-sfdc-domain             sfdc-soql                      └─ composes reviewer + deploy
                           sfdc-flow-builder
                           sfdc-field-management
                           sfdc-validation-rules
                           sfdc-permissions
                           sfdc-troubleshooting
                           bw-engagement-cycle
```

**RIC scoring** (Risk / Impact / Complexity) gates every change:

| Score | Zone | Routing |
|-------|------|---------|
| 3-6 | Green | Admin proceeds autonomously |
| 7-9 | Yellow | Admin proceeds, Architect notified async |
| 10-15 | Red | Architect must review before production deploy |

## Getting started

1. Clone this repo as your SFDX project root (or copy `.cursor/` into an existing project).
2. Connect your Salesforce orgs: `sf org login web --alias sandbox` and `sf org login web --alias production`.
3. Have your Architect populate `context/sfdc/` with org-specific domain context (see `context/sfdc/README.md`).
4. Start working. The rules activate automatically; skills are invoked by the change management loop.

## Structure

```
.cursor/
├── agents/                    # Autonomous multi-step workflows
│   ├── sfdc-change-reviewer.md
│   └── sfdc-deployment-manager.md
├── skills/                    # Step-by-step playbooks
│   ├── sfdc-impact-analysis/
│   ├── sfdc-ric-scoring/
│   ├── sfdc-deployment/
│   ├── sfdc-soql/
│   ├── sfdc-flow-builder/
│   ├── sfdc-field-management/
│   ├── sfdc-validation-rules/
│   ├── sfdc-permissions/
│   ├── sfdc-troubleshooting/
│   └── bw-engagement-cycle/   # Org-specific overlay
└── rules/                     # Always-on guardrails
    ├── sfdc-safety.mdc
    ├── sfdc-naming.mdc
    ├── sfdc-change-management.mdc
    └── bw-sfdc-domain.mdc     # Org-specific overlay
context/sfdc/                  # Architect-maintained domain context
change-log/                    # Change documentation
force-app/                     # Standard SFDX source
```

## Customizing for your org

The `bw-*` prefixed files are the Brightwheel-specific overlay. To adapt for a different org:

1. Replace files in `context/sfdc/` with your org's domain context.
2. Replace `bw-engagement-cycle` with a skill for your org's fragile automation patterns (or remove it if none exist).
3. `bw-sfdc-domain.mdc` needs no changes -- it reads generically from `context/sfdc/`.
